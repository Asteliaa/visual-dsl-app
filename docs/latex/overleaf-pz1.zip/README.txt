Overleaf: Menu -> Compiler = XeLaTeX, Main document = main.tex.
Шрифты Times New Roman/Courier New заменяются на TeX Gyre Termes/Cursor (метрически совместимы).
